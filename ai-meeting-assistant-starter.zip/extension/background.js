let transcript = [];

chrome.runtime.onMessage.addListener((msg, _sender, _resp) => {
  if (msg?.type === "caption-line") {
    transcript.push(msg.payload);
  }
});

chrome.runtime.onInstalled.addListener(() => {
  transcript = [];
});

async function summarize({ promptType, meetingTitle }) {
  const body = { meetingTitle, promptType, transcript };
  const resp = await fetch("https://YOUR_SERVER_DOMAIN/api/summarize", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  return await resp.json();
}

chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
  if (msg?.type === "summarize") {
    summarize(msg.payload).then(r => sendResponse(r)).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg?.type === "reset-buffer") {
    transcript = [];
    sendResponse({ ok: true });
  }
});