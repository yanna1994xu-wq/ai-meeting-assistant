const $ = sel => document.querySelector(sel);

$("#btnPreview").onclick = async () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { type: "get-transcript-buffer" }, resp => {
      $("#output").value = resp?.data?.map(x => x.text).join("\n") || "暂无数据";
    });
  });
};

$("#btnSummarize").onclick = async () => {
  const meetingTitle = $("#title").value.trim();
  const promptType = $("#promptType").value;
  $("#output").value = "生成中，请稍候…";
  chrome.runtime.sendMessage({ type: "summarize", payload: { meetingTitle, promptType } }, resp => {
    if (resp?.ok) $("#output").value = resp.summary;
    else $("#output").value = `出错：${resp?.error || "未知错误"}`;
  });
};

$("#btnReset").onclick = () => {
  chrome.runtime.sendMessage({ type: "reset-buffer" }, () => {
    $("#output").value = "已清空缓冲区。";
  });
};