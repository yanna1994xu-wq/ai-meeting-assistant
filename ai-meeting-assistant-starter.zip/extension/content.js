(() => {
  let lastLine = "";
  const buffer = [];

  function isCaptionNode(node) {
    if (!node || node.nodeType !== 1) return false;
    const el = node;
    const live = el.getAttribute("aria-live");
    return live === "polite" || live === "assertive";
  }

  function collectFromNode(node) {
    const text = node.innerText?.trim();
    if (text && text !== lastLine && text.length > 0 && text.length < 500) {
      lastLine = text;
      const line = { t: Date.now(), text };
      buffer.push(line);
      chrome.runtime.sendMessage({ type: "caption-line", payload: line });
    }
  }

  [...document.querySelectorAll('[aria-live="polite"], [aria-live="assertive"]')]
    .forEach(collectFromNode);

  const mo = new MutationObserver(muts => {
    for (const m of muts) {
      if (m.type === "childList") {
        m.addedNodes.forEach(n => {
          if (n.nodeType === 1) {
            const el = n;
            if (isCaptionNode(el)) collectFromNode(el);
            el.querySelectorAll?.('[aria-live="polite"], [aria-live="assertive"]').forEach(collectFromNode);
          }
        });
      }
    }
  });
  mo.observe(document.body, { childList: true, subtree: true });

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "get-transcript-buffer") {
      sendResponse({ ok: true, data: buffer.slice() });
    }
  });
})();