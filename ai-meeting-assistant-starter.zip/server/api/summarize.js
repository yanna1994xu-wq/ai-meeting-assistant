import fetch from "cross-fetch";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "Method not allowed" });

  try {
    const { meetingTitle = "", promptType = "todo", transcript = [] } = req.body || {};
    const text = transcript.map(x => `[${new Date(x.t).toLocaleTimeString()}] ${x.text}`).join("\n");
    const trimmed = text.length > 18000 ? text.slice(-18000) : text;

    const promptMap = {
      todo: "你是会议助理。请仅输出「待办事项清单」：每一项包含【任务】【负责人】【截止日期（若未提及请留空）】。",
      exec: "你是高层汇报助理。请用要点式输出：1) 会议目的 2) 关键结论 3) 风险与依赖 4) 决策与待办（含负责人）。",
      full: "你是资深会议记录员。请输出：会议背景、讨论要点、达成共识、未决问题、后续行动（负责人+截止）。"
    };

    const systemPrompt = promptMap[promptType] || promptMap.todo;
    const userPrompt = `会议标题：${meetingTitle || "（未命名）"}\n以下是会议字幕：\n---\n${trimmed}\n---`;

    const resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.2
      })
    });

    if (!resp.ok) {
      const text = await resp.text();
      return res.status(500).json({ ok: false, error: `OpenAI error: ${text}` });
    }

    const data = await resp.json();
    const summary = data.choices?.[0]?.message?.content?.trim() || "(无结果)";

    return res.status(200).json({ ok: true, summary });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
}